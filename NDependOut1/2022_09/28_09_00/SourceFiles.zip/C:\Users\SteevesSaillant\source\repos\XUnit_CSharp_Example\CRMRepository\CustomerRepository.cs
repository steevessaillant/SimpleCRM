﻿using CRMRepository.Entities;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using static System.Net.Mime.MediaTypeNames;

namespace CRMRepository
{
    public class CustomerRepository : IRepository<Customer>
    {
        private readonly List<Customer> tempDataStore = new();

   
       
        public void Add(Customer entity)
        {
            if (!tempDataStore.Exists(x => x.RowKey == entity.RowKey && x.PartitionKey == entity.PartitionKey))
            {
                tempDataStore.Add(entity);
            }
        }

        public void Clear()
        {
            tempDataStore.Clear();
            this.Save();
        }

        //for now exclude becuase it is not implemented
        public void Delete(Customer entity)
        {
            AzureTableClient.DeleteFromTable(entity);
        }

        public void DeleteRange(List<Customer> entities)
        {
            AzureTableClient.DeleteRangeFromTableAsync(entities);
        }

        public List<Customer> FetchAll()
        {
            return AzureTableClient.GetAllFromTable();
        }

        public Customer Get(Customer entity)
        {
            if (tempDataStore.Exists(x => x.RowKey == entity.RowKey && x.PartitionKey == entity.PartitionKey))
            {
                return tempDataStore.Find(x => x.RowKey == entity.RowKey && x.PartitionKey == entity.PartitionKey);
            }
          
            return null;
        }


        public Customer GetByRowKey(string RowKey)
        {
            if (tempDataStore.Exists(x => x.RowKey == RowKey))
            {
                return tempDataStore.Find(x => x.RowKey == RowKey);
            }
            return null;
        }

        public void Save()
        {
            AzureTableClient.SaveToTableAsync(tempDataStore);
        }

        public void Update(Customer entity)
        {
            throw new NotImplementedException();
        }
    }
}
