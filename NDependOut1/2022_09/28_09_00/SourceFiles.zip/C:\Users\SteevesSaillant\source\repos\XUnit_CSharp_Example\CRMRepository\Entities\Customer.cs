﻿using Azure;
using Azure.Data.Tables;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CRMRepository.Entities
{
    [DataContract]
    public class Customer : IEquatable<Customer>, ITableEntity
    {
        /// <summary>
        /// Id of the customer
        /// </summary>
        [ExcludeFromCodeCoverage]
        [DataMember]
        public string RowKey { get; set; }

        [ExcludeFromCodeCoverage]
        [DataMember]
        public string FirstName { get; set; }
        [ExcludeFromCodeCoverage]
        [DataMember]
        public string LastName { get; set; }
        [ExcludeFromCodeCoverage]
        [DataMember]
        public string PartitionKey { get; set; }
        [ExcludeFromCodeCoverage]
        [DataMember]
        public DateTimeOffset? Timestamp { get; set; }
        [ExcludeFromCodeCoverage]
        [DataMember]
        public ETag ETag { get; set; }

        public bool Equals(Customer other)
        {
            return this.RowKey == other.RowKey && this.FirstName == other.FirstName && this.LastName == other.LastName && this.PartitionKey == other.PartitionKey;
        }
    }
}
