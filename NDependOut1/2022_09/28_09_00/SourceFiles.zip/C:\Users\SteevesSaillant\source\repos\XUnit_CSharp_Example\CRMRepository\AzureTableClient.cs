﻿using Azure;
using Azure.Data.Tables;
using CRMRepository.Entities;
using Microsoft.Extensions.Azure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMRepository
{
    public static class AzureTableClient
    {
        private static readonly string azureTableUrl = "https://simplecrmfilestore.table.core.windows.net/Customers";
        private static readonly TableClient tableClient = new(new Uri(azureTableUrl),
        "Customers", new TableSharedKeyCredential("simplecrmfilestore", "x2WRxcLvZ2K6WFwOb4OUPiJqvI2RBKm6rd7OuMfxz3OBRtASQ/KsTm2rVHxE8apwp2Zfs9s+RnNy+AStIysb/w=="));

        internal static async void SaveToTableAsync(List<Customer> customers)
        {
            if (customers == null)
            {
                throw new ArgumentNullException(nameof(customers)); 
            }
            customers.ForEach(x =>
            {
                if (x is null)
                {
                    throw new ArgumentNullException(nameof(x));
                }
                
                tableClient.AddEntity(x);
            });

            List<TableTransactionAction> postedCustomers = new List<TableTransactionAction>();
            postedCustomers.AddRange(customers.Select(x => new TableTransactionAction(TableTransactionActionType.Add, x)));
            Response<IReadOnlyList<Response>> response = await tableClient.SubmitTransactionAsync(postedCustomers);
        }
        
        internal static async void DeleteRangeFromTableAsync(List<Customer> customers)
        {
            List<TableTransactionAction> postedCustomers = new List<TableTransactionAction>();
            postedCustomers.AddRange(customers.Select(x => new TableTransactionAction(TableTransactionActionType.Delete, x)));
            Response<IReadOnlyList<Response>> response = await tableClient.SubmitTransactionAsync(postedCustomers);
        }


        internal static List<Customer> GetAllFromTable()
        {
            var customers = new List<Customer>();
            Pageable<Customer> results = tableClient.Query<Customer>();

            foreach (Customer customer in results)
            {
                customers.Add(customer);
            }
            return customers;

        }

        internal static void DeleteFromTable(Customer entity)
        {
            tableClient.DeleteEntity(entity.RowKey, entity.PartitionKey);
        }
    }
}