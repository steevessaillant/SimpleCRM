﻿using CRMRepository.Entities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.File;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;

namespace CRMRepository
{
    public static class MemoryToFileDatastore
    {
        private static readonly CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=simplecrmfilestore;AccountKey=x2WRxcLvZ2K6WFwOb4OUPiJqvI2RBKm6rd7OuMfxz3OBRtASQ/KsTm2rVHxE8apwp2Zfs9s+RnNy+AStIysb/w==;EndpointSuffix=core.windows.net");


        private static void WriteEnumerableToFile<T>(IEnumerable<T> data, string fileName)
        {

            var serializer = new DataContractJsonSerializer(data.GetType());
            using var stream = new FileStream(fileName, FileMode.Truncate);

            serializer.WriteObject(stream, data);

        }

        public static void ExportToTextFile<T>(this List<T> data, string fileName)
        {
            WriteEnumerableToFile(data.AsEnumerable(), fileName);
        }

        public static string GetCustomerListAsText(this List<Customer> data, string fileName)
        {
            if (File.Exists(fileName))
            {
                return File.ReadAllText(fileName);
            }
            else
            {
                throw new FileNotFoundException();
            }

        }

        public static MemoryStream ToStream<T>(this List<T> data)
        {
            var stream = new MemoryStream();
            var serializer = new DataContractJsonSerializer(data.GetType());
            serializer.WriteObject(stream, data);
            return stream;
        }

        public static async void ClearCloudCustomerDataSource<T>(this List<Customer> data, string fileName)
        {
            var file = SetCloudFile();

            if (file.ExistsAsync().Result)
            {
                file.DownloadToFileAsync(fileName, FileMode.Open).Wait();
                using var sr = File.OpenText(fileName);
                var json = sr.ReadToEnd();
                data = new List<Customer>();
                file.UploadTextAsync(JsonConvert.SerializeObject(data)).Wait();
            }
        }


        public static async void LoadCustomersFromCloudTextFile<T>(this List<Customer> data, string fileName)
        {
            var file = SetCloudFile();

            if (file.ExistsAsync().Result)
            {
                File.Delete(fileName);
                file.DownloadToFileAsync(fileName, FileMode.CreateNew).Wait();
                using var sr = File.OpenText(fileName);
                var json = sr.ReadToEnd();
                data = JsonConvert.DeserializeObject<List<Customer>>(json);
            }
            else
            {
                await file.UploadTextAsync(JsonConvert.SerializeObject(data));
            }
        }

        private static void CreateIfFileNotFoundAndReadAll<Customer>(List<Customer> data, string fileName)
        {
            if (File.Exists(fileName))
            {
                using var sr = File.OpenText(fileName);
                var json = sr.ReadToEnd();
                data.AddRange(JsonConvert.DeserializeObject<List<Customer>>(json));
                sr.Close();
            }
            else
            {


            }

        }

        public static byte[] ToByteArray(this string @this)
        {
            Encoding encoding = Activator.CreateInstance<ASCIIEncoding>();
            return encoding.GetBytes(@this);
        }

        private static CloudFile SetCloudFile()
        {
            return storageAccount
                .CreateCloudFileClient()
                .GetShareReference("simplecrmfiles")
                .GetRootDirectoryReference()
                .GetFileReference("Customer.json");

        }
    }

    [ExcludeFromCodeCoverage]
    public class CustomerComparer : IEqualityComparer<Customer>
    {
        public int GetHashCode(Customer customer)
        {
            if (customer == null)
            {
                return 0;
            }
            return customer.Id.GetHashCode();
        }

        public bool Equals(Customer x1, Customer x2)
        {
            if (object.ReferenceEquals(x1, x2))
            {
                return true;
            }
            if (object.ReferenceEquals(x1, null) ||
                object.ReferenceEquals(x2, null))
            {
                return false;
            }
            return x1.Id == x2.Id;
        }
    }
}
