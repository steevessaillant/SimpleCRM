﻿using CRMRepository.Entities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.File;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CRMRepository
{
    public class CustomerRepository : IRepository<Customer>, IPersistableFile
    {
        private List<Customer> tempDataStore = new();
        private static readonly CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=simplecrmfilestore;AccountKey=x2WRxcLvZ2K6WFwOb4OUPiJqvI2RBKm6rd7OuMfxz3OBRtASQ/KsTm2rVHxE8apwp2Zfs9s+RnNy+AStIysb/w==;EndpointSuffix=core.windows.net");
        public string DataSourceFileLocalPath
        {
            get
            {
                var possiblePath = Directory.GetParent(Environment.CurrentDirectory).FullName + "\\Data\\Customers.json";

                if (File.Exists(possiblePath))
                {
                    return possiblePath;
                }
                else
                {
                    var dirInfo = Directory.CreateDirectory(Directory.GetParent(Environment.CurrentDirectory).FullName + "\\Data");
                    using var file = File.CreateText(dirInfo.FullName + "\\Customers.json");
                    file.Close();
                    return possiblePath;
                }

            }
        }

        public CustomerRepository(bool reset = false)
        {
            if (reset)
            {
                tempDataStore.ClearCloudCustomerDataSource<Customer>(DataSourceFileLocalPath);
            }
            else
            {
                tempDataStore.LoadCustomersFromCloudTextFile<Customer>(DataSourceFileLocalPath);
            }

        }

        public void Add(Customer entity)
        {
            if (tempDataStore == null)
            {
                tempDataStore = new List<Customer>();
            }
            if (tempDataStore.Any(x => x.Id == entity.Id))
            {
                //duplicate Id here just return
                return;
            }
            else
            {
                tempDataStore.Add(entity);
            }
            if (!tempDataStore.Exists(x => x.Id == entity.Id))
            {
                tempDataStore.Add(entity);
            }
        }

        public void Clear()
        {
            tempDataStore ??= new List<Customer>();
            tempDataStore.ClearCloudCustomerDataSource<Customer>(DataSourceFileLocalPath);
        }

        //for now exclude becuase it is not implemented
        public void Delete(Customer entity)
        {
            if (tempDataStore == null)
            {
                tempDataStore = new List<Customer>();
            }
            tempDataStore.Remove(entity);
        }

        public List<Customer> FetchAll()
        {
            var cloudFile = SetCloudFile();
            var fileContent = cloudFile.DownloadTextAsync().Result;
            if (fileContent == "\0\0")
            {
                fileContent = "[]";
            }

            tempDataStore = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Customer>>(fileContent);
            return tempDataStore;
        }

        public Customer Get(Customer entity)
        {
            tempDataStore ??= new List<Customer>();
            if (tempDataStore.Exists(x => x.Id == entity.Id))
            {
                return entity;
            }
            return null;
        }

        public Customer GetById(string Id)
        {
            var cloudFile = SetCloudFile();
            var fileContent = cloudFile.DownloadTextAsync().Result;
            if (fileContent == "\0\0")
            {
                fileContent = "[]";
            }

            tempDataStore = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Customer>>(fileContent);
            return tempDataStore.FirstOrDefault(x => x.Id == Id);
        }

        public async void Save()
        {
            tempDataStore ??= new List<Customer>();

            tempDataStore
                .ExportToTextFile<Customer>(this.DataSourceFileLocalPath);


            var cloudFile = SetCloudFile();
            cloudFile.UploadFromFileAsync(this.DataSourceFileLocalPath).Wait();



            if (!cloudFile.ExistsAsync().Result)
            {
                throw new Exception("File does not exist in Azure Cloud");
            }

        }

        private static CloudFile SetCloudFile()
        {
            return storageAccount
                .CreateCloudFileClient()
                .GetShareReference("simplecrmfiles")
                .GetRootDirectoryReference()
                .GetFileReference("Customer.json");

        }

        public void Update(Customer entity)
        {
            throw new NotImplementedException();
        }
    }
}
