﻿using CRMRepository;
using CRMRepository.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CRMRestApiV2.Controllers
{
    /// <summary>
    /// CRMCustomerController form rest api/CRMCustomers
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CRMCustomerController : ControllerBase
    {
        private readonly ILogger<CRMCustomerController> _logger;
        private readonly IRepository<Customer> repository;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="reset"></param>
        /// <param name="repository"></param>
        public CRMCustomerController(ILogger<CRMCustomerController> logger, bool reset = false, IRepository<Customer>? repository = null)
        {
            _logger = logger;
            this.repository = repository == null ?
                new CustomerRepository(reset) : repository;

        }
        /// <summary>
        /// Get all customers
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IEnumerable<Customer> Get()
        {
            return this.repository.FetchAll().ToArray();
        }

        /// <summary>
        /// Get customer by id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet("{Id}")]
        public Customer Get(string Id)
        {
            return this.repository.GetById(Id).Result;
        }
        /// <summary>
        /// Post customer
        /// </summary>
        /// <param name="customer"></param>
        [HttpPost]
        public void Post(Customer customer)
        {
            this.repository.Add(customer);
            this.repository.Save();
        }
        /// <summary>
        /// Delete customer
        /// </summary>
        /// <param name="customer"></param>
        [HttpDelete]
        public void Delete(Customer customer)
        {
            try
            {
                this.repository.Delete(customer);
                this.repository.Save();
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// Clears all data and saves file to cloud
        /// </summary>
        [HttpGet("Clear")]
        public IEnumerable<Customer>? Clear()
        {
            try
            {
                this.repository.Clear();
                return this.repository.FetchAll().ToArray();
            }
            catch
            {
                return null;
            }

        }
        /// <summary>
        /// Delete customer
        /// </summary>
        /// <param name="customer"></param>
        [HttpDelete("{Id}")]
        public void Delete(string Id)
        {
            try
            {
                this.repository.Delete(this.repository.GetById(Id).Result);
                this.repository.Save();
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// <summary>
        /// Remove all data form the file datasource leaving just an empty array --> []
        /// </summary>
        [NonAction]
        protected void ClearDataSource()
        {
            this.repository.Clear();
        }

        /// <summary>
        /// Gets the fle that contains the customer (local path)
        /// </summary>
        /// <returns>this.repository.DataSourceFileLocalPath</returns>
        [NonAction]
        public string GetDataSourceFileLocalPath()
        {
            return this.repository.DataSourceFileLocalPath;
        }
    }
}
