﻿using CRMRepository.Entities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.File;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CRMRepository
{
    public class CustomerRepository : IRepository<Customer>, IPersistableFile
    {
        private List<Customer> tempDataStore = new();
        private static readonly CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=simplecrmfilestore;AccountKey=x2WRxcLvZ2K6WFwOb4OUPiJqvI2RBKm6rd7OuMfxz3OBRtASQ/KsTm2rVHxE8apwp2Zfs9s+RnNy+AStIysb/w==;EndpointSuffix=core.windows.net");
        public string DataSourceFileLocalPath
        {
            get
            {
                if (!File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data\\Customers.json"))
                {
                    if (Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data"))
                    {
                        if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data\\Customers.json"))
                        {
                            return Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data\\Customers.json";
                        }
                        else
                        {
                            var newFileStream = File.CreateText(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data\\Customers.json");

                            newFileStream.Write("[]");
                            newFileStream.Close();
                            newFileStream.Dispose();
                        }

                    }
                    else
                    {
                        var newDir = Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data");
                        using var newFile = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data\\Customers.json");
                    }
                    using var streamWriter = File.CreateText(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data\\Customers.json");
                    streamWriter.Write("[]");
                    streamWriter.Close();
                }
                return Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SimpleCRM\\Data\\Customers.json";
            }
        }

        public CustomerRepository(bool reset = false)
        {
            if (reset)
            {
                tempDataStore.ClearCloudCustomerDataSource<Customer>(DataSourceFileLocalPath);
            }
            else
            {
                tempDataStore.LoadCustomersFromCloudTextFile<Customer>(DataSourceFileLocalPath);
            }

        }

        public void Add(Customer entity)
        {
            if (tempDataStore == null)
            {
                tempDataStore = new List<Customer>();
            }
            if (tempDataStore.Any(x => x.Id == entity.Id))
            {
                //duplicate Id here just return
                return;
            }
            else
            {
                tempDataStore.Add(entity);
            }
            if (!tempDataStore.Exists(x => x.Id == entity.Id))
            {
                tempDataStore.Add(entity);
            }
        }

        public void Clear()
        {
            tempDataStore ??= new List<Customer>();
            tempDataStore.ClearCloudCustomerDataSource<Customer>(DataSourceFileLocalPath);
        }

        //for now exclude becuase it is not implemented
        public void Delete(Customer entity)
        {
            if (tempDataStore == null)
            {
                tempDataStore = new List<Customer>();
            }
            tempDataStore.Remove(entity);
        }

        public List<Customer> FetchAll()
        {
            var cloudFile = SetCloudFile();
            var fileContent = cloudFile.DownloadTextAsync().Result;
            if (fileContent == "\0\0")
            {
                fileContent = "[]";
            }

            tempDataStore = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Customer>>(fileContent);
            return tempDataStore;
        }

        public Customer Get(Customer entity)
        {
            tempDataStore ??= new List<Customer>();
            if (tempDataStore.Exists(x => x.Id == entity.Id))
            {
                return entity;
            }
            return null;
        }

        public async Task<Customer> GetById(string Id)
        {
            return await Task.Run(() =>
            {
                var cloudFile = SetCloudFile();
                var fileContent = cloudFile.DownloadTextAsync().Result;
                if (fileContent == "\0\0")
                {
                    fileContent = "[]";
                }

                tempDataStore = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Customer>>(fileContent);
                return tempDataStore.FirstOrDefault(x => x.Id == Id);
            });
            
        }

        public async void Save()
        {
            await Task.Run(() =>
            {
                tempDataStore ??= new List<Customer>();

                tempDataStore
                    .ExportToTextFile<Customer>(this.DataSourceFileLocalPath);


                var cloudFile = SetCloudFile();
                if(!MemoryToFileDatastore.IsFileLocked(this.DataSourceFileLocalPath))
                {
                    cloudFile.UploadFromFileAsync(this.DataSourceFileLocalPath).Wait();
                }
                
                if (!cloudFile.ExistsAsync().Result)
                {
                    throw new Exception("File does not exist in Azure Cloud");
                }
            });
          

        }

        private static CloudFile SetCloudFile()
        {
            return storageAccount
                .CreateCloudFileClient()
                .GetShareReference("simplecrmfiles")
                .GetRootDirectoryReference()
                .GetFileReference("Customer.json");

        }

        public void Update(Customer entity)
        {
            throw new NotImplementedException();
        }
    }
}
